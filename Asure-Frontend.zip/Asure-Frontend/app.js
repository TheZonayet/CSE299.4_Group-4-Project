// Simple fake database (for demo only)
const registeredUsers = [];
const verifiedCodes = ["ASURE123", "CERT789", "PROD456"]; 

function registerUser() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const registerResult = document.getElementById("registerResult");

  if (name === "" || email === "") {
    registerResult.innerText = "⚠️ Please fill all fields!";
    registerResult.style.color = "red";
  } else {
    registeredUsers.push({ name, email });
    registerResult.innerText = "✅ Registered successfully!";
    registerResult.style.color = "green";

    // Clear input boxes
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
  }
}

function verifyCode() {
  const code = document.getElementById("codeInput").value.trim();
  const verifyResult = document.getElementById("verifyResult");

  if (code === "") {
    verifyResult.innerText = "⚠️ Please enter a code!";
    verifyResult.style.color = "red";
  } else if (verifiedCodes.includes(code)) {
    verifyResult.innerText = "✅ Authentic record found. Verified successfully!";
    verifyResult.style.color = "green";
  } else {
    verifyResult.innerText = "❌ Record not found. Possible fake or unregistered!";
    verifyResult.style.color = "red";
  }
}
