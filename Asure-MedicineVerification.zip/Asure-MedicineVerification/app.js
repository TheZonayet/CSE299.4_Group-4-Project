// Fake database based on your SQL file
const medicineDatabase = [
    {
        code: "MED1001",
        name: "Napa Extra",
        power: "500mg",
        manufacturer: "Beximco Pharma",
        batch: "BX2024A",
        expiry: "2025-09-12"
    },
    {
        code: "MED2001",
        name: "Amodis",
        power: "400mg",
        manufacturer: "Square Pharma",
        batch: "SQ7788",
        expiry: "2026-02-09"
    }
];

// Verify Function
function verifyMedicine() {
    const inputCode = document.getElementById("medicineCode").value;
    const result = document.getElementById("result");
    const details = document.getElementById("details");

    const medicine = medicineDatabase.find(m => m.code === inputCode);

    if (medicine) {
        result.innerHTML = "✔ Authentic Medicine Found";
        result.style.color = "green";

        details.innerHTML = `
            <p><b>Name:</b> ${medicine.name}</p>
            <p><b>Power:</b> ${medicine.power}</p>
            <p><b>Manufacturer:</b> ${medicine.manufacturer}</p>
            <p><b>Batch:</b> ${medicine.batch}</p>
            <p><b>Expiry:</b> ${medicine.expiry}</p>
        `;
    } else {
        result.innerHTML = "❌ Fake Medicine / Not Found";
        result.style.color = "red";
        details.innerHTML = "";
    }
}
